import Vue from "vue";
import Router from "vue-router";
import AvailableVehiclesListComponent from "./components/AvailableVehiclesListComponent.vue";
import VehicleComponent from "./components/VehicleComponent.vue";
import PriceComponent from "./components/PriceComponent.vue";
import HiredVehiclesListComponent from "./components/HiredVehiclesListComponent.vue";
 
Vue.use(Router);
 
export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "available-vehicles",
      alias: "/vehicle",
      component: AvailableVehiclesListComponent,
      children: [
        {
          path: "/vehicle/:id",
          name: "vehicle-details",
          component: VehicleComponent,
          props: true
          
        },       
        {
            path: "/price/:vehicle/:id/:startDate/:endDate/:totalCost",
            name: "price",
            component: PriceComponent,
            props: true
            
        }
          
      ]
    },
    {
        path: "/hired",
        name: "hired-vehicles",
        component: HiredVehiclesListComponent,
    }
  ]
});