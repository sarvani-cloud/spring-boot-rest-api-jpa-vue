<template>
    <div id="app" class="container-fluid">
        <div class="site-info">
            <h1>Vehicle Hire Booking System</h1>
            <h3>Welcome</h3>
        </div>
        <nav>
            <router-link class="btn btn-primary" to="/">Available Vehicles</router-link>
            <router-link class="btn btn-primary" to="/hired">Hired Vehicles</router-link>
        </nav>
        <br/>
        <router-view/>
    </div>
</template>
 
<script>
export default {
  name: "app"
};
</script>
 
<style>
.site-info {
  color: blue;
  margin-bottom: 20px;
}
 
.btn-primary {
  margin-right: 5px;
}
 
.container-fluid {
  text-align: center;
}

label {
    color: blue;
    font-weight: bold;
}
</style>