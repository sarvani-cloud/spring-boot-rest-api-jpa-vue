<template>
    <div class="container">
        <div class="container">
            <table class="table">
                <thead>
                <tr>
                    <th>Number</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Fuel Type</th>
                    <th>Size</th>
                    <th>Price</th>
                    <th>Customer name</th>
                    <th>Customer Type</th>
                    <th>Customer Insurance Id</th>
                    <th>Finish Date</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="vehicle in hiredVehicles" v-bind:key="vehicle.id">
                    <td>{{vehicle.registrationNumber}}</td>
                    <td>{{vehicle.make}}</td>
                    <td>{{vehicle.model}}</td>
                    <td>{{vehicle.fuelType}}</td>
                    <td>{{vehicle.categoryDetails.size}}</td>
                    <td>{{vehicle.categoryDetails.price}}</td>
                    <td>{{vehicle.customer.name}}</td>
                    <td>{{vehicle.customer.type}}</td>
                    <td>{{vehicle.customer.insuranceId}}</td>
                    <td>{{vehicle.finishDate}}</td>
                </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <router-view @refreshData="refreshList"></router-view>
        </div>
    </div>
</template>
 
<script>
import http from "../http-common";
 
export default {
  name: "hired-vehicles-list",
  data() {
    return {
      hiredVehicles: []
    };
  },
  methods: {
    /* eslint-disable no-console */
    retrieveHiredVehicles() {
      http
        .get("/findAllVehiclesThatAreAlreadyHired")
        .then(response => {
          this.hiredVehicles = response.data; // JSON are parsed automatically.
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    },
    refreshList() {
      this.retrieveHiredVehicles();
    }
    /* eslint-enable no-console */
  },
  mounted() {
    this.retrieveHiredVehicles();
  }
};
</script>
 
<style>
.list {
  text-align: left;
  max-width: 450px;
  margin: auto;
}
</style>