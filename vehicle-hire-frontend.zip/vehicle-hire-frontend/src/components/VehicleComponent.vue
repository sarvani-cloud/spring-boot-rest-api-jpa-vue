<template>
  <div class="container" v-if="this.vehicle.id">
    <h4>Vehicle Details</h4>
    <div class="form-group">
      <label>Number: </label> {{this.vehicle.registrationNumber}}
    </div>
    <div class="form-group">
      <label>Make: </label> {{this.vehicle.make}}
    </div>
    <div class="form-group">
      <label>Model: </label> {{this.vehicle.model}}
    </div>
    <div class="form-group">
      <label>Fuel Type: </label> {{this.vehicle.fuelType}}
    </div>
    <div class="form-group">
      <label>Category: </label> {{this.vehicle.categoryDetails.size}}
    </div>
    <div class="form-group">
      <label>Price per day: </label> {{this.vehicle.categoryDetails.price}}
    </div>
    <div class="form-group">
      <label>Start date: </label>
      <date-picker v-model=startDate valueType="format"/>
    </div>
    <div class="form-group">
      <label>End date: </label>
      <date-picker v-model=endDate valueType="format"/>
   </div>

    <div>
        <nav>
            <router-link 
                class="btn btn-primary" 
                :to="{
                        name: 'price',
                        params: { vehicle: vehicle, id: vehicle.id, startDate: startDate.toString(), endDate: endDate.toString(), totalCost: result() }
                    }"  >
                Find Price
            </router-link>
            
        </nav>
    </div>
    
    <router-view/>
    
  </div>
  <div v-else>
    <br/>
    <p>Please click on a Vehicle...</p>
  </div>
</template>

<script>
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';

export default {
  name: "vehicle-details",
  components: { 
      DatePicker 
    },
  data(){
      return{
          startDate: '',
          endDate: '',
          totalCost: 0
      }
  },
  methods:{
      result: function () {
        var noOfDays = (new Date(this.endDate) - new Date(this.startDate))/ (1000 * 60 * 60 * 24);
        noOfDays++;
        return this.vehicle.categoryDetails.price * noOfDays;
      }
  },
  props: ["vehicle"]
 
};
</script>
<style scoped>

</style>