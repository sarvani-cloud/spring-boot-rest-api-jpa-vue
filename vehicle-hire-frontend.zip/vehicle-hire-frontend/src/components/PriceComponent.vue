<template>
    <div  v-if="this.vehicle.id">
        <h4>Vehicle Details</h4>
        <div class="form-group">
        <label>Number:</label> {{this.vehicle.registrationNumber}}
        </div>
        <div class="form-group">
        <label>Make: </label> {{this.vehicle.make}}
        </div>
        <div class="form-group">
        <label>Model: </label> {{this.vehicle.model}}
        </div>
        <div class="form-group">
        <label>Fuel Type: </label> {{this.vehicle.fuelType}}
        </div>
        <div class="form-group">
        <label>Category: </label> {{this.vehicle.categoryDetails.size}}
        </div>
        <div class="form-group">
        <label>Price per day: </label> {{this.vehicle.categoryDetails.price}}
        </div>
        <div class="form-group">
            <label>Start date: </label> {{this.startDate}}
        </div>
        <div class="form-group">
            <label>End date: </label> {{this.endDate}}
        </div>
        <div class="form-group">
            <label>Total Cost: </label> {{this.totalCost}}
        </div>    
    </div>
  
</template>

<script>
export default {
    name:"price-details",
    props: ["vehicle","startDate", "endDate", "totalCost"]
    
};
</script>

<style>

</style>